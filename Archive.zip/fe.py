import pandas as pd
import numpy as np

def ohlc_feats(data):
    o = data.OPEN.values.astype(float)
    h = data.HIGH.values.astype(float)
    l = data.LOW.values.astype(float)
    c = data.CLOSE.values.astype(float)
    
    ohlc_feats = pd.DataFrame({'OPEN_TIME': data.OPEN_TIME.values})
    
    ohlc_feats['OHLC'] = h - o + h - l + c - l
    ohlc_feats['OLHC'] = o - l + h - l + h - c
    
    ohlc_feats['O_EQUAL_C'] = o == c
    ohlc_feats['O_EQUAL_L'] = o == l
    ohlc_feats['O_EQUAL_H'] = o == h
    ohlc_feats['C_EQUAL_H'] = c == h
    ohlc_feats['C_EQUAL_L'] = c == l
    ohlc_feats['L_EQUAL_H'] = l == h
    
    ohlc_feats['O_GREATER_C'] = o > c
    
    ohlc_feats['O_C_MEAN'] = (o + c)/2
    ohlc_feats['L_H_MEAN'] = (l + h)/2
    
    ohlc_feats['O_OC_MEAN_FRAC'] = o / ohlc_feats['O_C_MEAN']
    ohlc_feats['L_OC_MEAN_FRAC'] = l / ohlc_feats['O_C_MEAN']
    ohlc_feats['H_OC_MEAN_FRAC'] = h / ohlc_feats['O_C_MEAN']
    ohlc_feats['C_OC_MEAN_FRAC'] = c / ohlc_feats['O_C_MEAN']
    
    ohlc_feats['O_LH_MEAN_FRAC'] = o / ohlc_feats['L_H_MEAN']
    ohlc_feats['L_LH_MEAN_FRAC'] = l / ohlc_feats['L_H_MEAN']
    ohlc_feats['H_LH_MEAN_FRAC'] = h / ohlc_feats['L_H_MEAN']
    ohlc_feats['C_LH_MEAN_FRAC'] = c / ohlc_feats['L_H_MEAN']
    
    ohlc_feats['O_GREATER_LH_MEAN'] = o > ohlc_feats['L_H_MEAN']
    ohlc_feats['C_GREATER_LH_MEAN'] = c > ohlc_feats['L_H_MEAN']
    
    ohlc_feats['O_C_MEAN__L_H_MEAN__DIFF']     = ohlc_feats['O_C_MEAN'] - ohlc_feats['L_H_MEAN']
    ohlc_feats['O_C_MEAN__L_H_MEAN__DIFF_ABS'] = np.abs(ohlc_feats['O_C_MEAN'] - ohlc_feats['L_H_MEAN'])
    ohlc_feats['O_C_MEAN__L_H_MEAN__GREATER']  = ohlc_feats['O_C_MEAN'] > ohlc_feats['L_H_MEAN']
    
    ohlc_feats['O_L_DIFF'] = o - l
    ohlc_feats['O_H_DIFF'] = o - h
    ohlc_feats['C_L_DIFF'] = c - l
    ohlc_feats['C_H_DIFF'] = c - h
    ohlc_feats['O_C_DIFF'] = o - c
    ohlc_feats['L_H_DIFF'] = l - h
    
    ohlc_feats['O_L_DIFF_ABS'] = np.abs(o - l)
    ohlc_feats['O_H_DIFF_ABS'] = np.abs(o - h)
    ohlc_feats['C_L_DIFF_ABS'] = np.abs(c - l)
    ohlc_feats['C_H_DIFF_ABS'] = np.abs(c - h)
    ohlc_feats['O_C_DIFF_ABS'] = np.abs(o - c)
    ohlc_feats['L_H_DIFF_ABS'] = np.abs(l - h)
    
    ohlc_feats['O_C_MEAN_PERCENTILE']     = (ohlc_feats['O_C_MEAN'] - l)/(h - l)
    ohlc_feats['O_PERCENTILE']            = (o - l)/(h - l)
    ohlc_feats['C_PERCENTILE']            = (c - l)/(h - l)
    ohlc_feats['O_C_PERCENTILE_DIFF']     = ohlc_feats['O_PERCENTILE'] - ohlc_feats['C_PERCENTILE']
    ohlc_feats['O_C_PERCENTILE_DIFF_ABS'] = np.abs(ohlc_feats['O_PERCENTILE'] - ohlc_feats['C_PERCENTILE'])
    
    return ohlc_feats

def ohlc_cross_feats(data):
    o = data.OPEN.values.astype(float)
    h = data.HIGH.values.astype(float)
    l = data.LOW.values.astype(float)
    c = data.CLOSE.values.astype(float)
    
    ohlc_feats = pd.DataFrame({'OPEN_TIME': data.OPEN_TIME.values[1:]})
    
    ohlc_feats['O_O1_EQUAL'] = o[1:] == o[:-1]
    ohlc_feats['H_H1_EQUAL'] = h[1:] == h[:-1]
    ohlc_feats['L_L1_EQUAL'] = l[1:] == l[:-1]
    ohlc_feats['C_C1_EQUAL'] = c[1:] == c[:-1]
    
    ohlc_feats['O_O1_GREATER'] = o[1:] > o[:-1]
    ohlc_feats['O_H1_GREATER'] = o[1:] > h[:-1]
    ohlc_feats['O_L1_GREATER'] = o[1:] > l[:-1]
    ohlc_feats['O_C1_GREATER'] = o[1:] > c[:-1]
    
    ohlc_feats['H_O1_GREATER'] = h[1:] > o[:-1]
    ohlc_feats['H_H1_GREATER'] = h[1:] > h[:-1]
    ohlc_feats['H_L1_GREATER'] = h[1:] > l[:-1]
    ohlc_feats['H_C1_GREATER'] = h[1:] > c[:-1]
    
    ohlc_feats['L_O1_GREATER'] = l[1:] > o[:-1]
    ohlc_feats['L_H1_GREATER'] = l[1:] > h[:-1]
    ohlc_feats['L_L1_GREATER'] = l[1:] > l[:-1]
    ohlc_feats['L_C1_GREATER'] = l[1:] > c[:-1]
    
    ohlc_feats['C_O1_GREATER'] = c[1:] > o[:-1]
    ohlc_feats['C_H1_GREATER'] = c[1:] > h[:-1]
    ohlc_feats['C_L1_GREATER'] = c[1:] > l[:-1]
    ohlc_feats['C_C1_GREATER'] = c[1:] > c[:-1]
    
    ohlc_feats['O_O1_ABS_PERC_DIFF'] = (o[1:] - o[:-1]) / o[:-1]
    ohlc_feats['O_H1_ABS_PERC_DIFF'] = (o[1:] - h[:-1]) / h[:-1]
    ohlc_feats['O_L1_ABS_PERC_DIFF'] = (o[1:] - l[:-1]) / l[:-1]
    ohlc_feats['O_C1_ABS_PERC_DIFF'] = (o[1:] - c[:-1]) / c[:-1]
    
    ohlc_feats['H_O1_ABS_PERC_DIFF'] = (h[1:] - o[:-1]) / o[:-1]
    ohlc_feats['H_H1_ABS_PERC_DIFF'] = (h[1:] - h[:-1]) / h[:-1]
    ohlc_feats['H_L1_ABS_PERC_DIFF'] = (h[1:] - l[:-1]) / l[:-1]
    ohlc_feats['H_C1_ABS_PERC_DIFF'] = (h[1:] - c[:-1]) / c[:-1]
    
    ohlc_feats['L_O1_ABS_PERC_DIFF'] = (l[1:] - o[:-1]) / o[:-1]
    ohlc_feats['L_H1_ABS_PERC_DIFF'] = (l[1:] - h[:-1]) / h[:-1]
    ohlc_feats['L_L1_ABS_PERC_DIFF'] = (l[1:] - l[:-1]) / l[:-1]
    ohlc_feats['L_C1_ABS_PERC_DIFF'] = (l[1:] - c[:-1]) / c[:-1]
    
    ohlc_feats['C_O1_ABS_PERC_DIFF'] = (c[1:] - o[:-1]) / o[:-1]
    ohlc_feats['C_H1_ABS_PERC_DIFF'] = (c[1:] - h[:-1]) / h[:-1]
    ohlc_feats['C_L1_ABS_PERC_DIFF'] = (c[1:] - l[:-1]) / l[:-1]
    ohlc_feats['C_C1_ABS_PERC_DIFF'] = (c[1:] - c[:-1]) / c[:-1]
    
    ohlc_feats['OC_ABS_PERC_GREATER'] = np.abs(o[1:] - c[1:]) > np.abs(o[:-1] - c[:-1])
    ohlc_feats['LH_ABS_PERC_GREATER'] = np.abs(l[1:] - h[1:]) > np.abs(l[:-1] - h[:-1])
    
    ohlc_feats['LH_ENGULF'] = (l[1:] < l[:-1]) & (h[1:] > h[:-1])
    ohlc_feats['LH_ENGULFED'] = (l[1:] > l[:-1]) & (h[1:] < h[:-1])
    
    return ohlc_feats

def vol_feats(data):
    bv = data.VOLUME.values.astype(float)
    qv = data.QUOTE_VOL.values.astype(float)
    tbv = data.TAKE_BASE_VOL.values.astype(float)
    tqv = data.TAKE_QUOTE_VOL.values.astype(float)
    nt = data.NUM_TRADES.values.astype(float)
    
    vol_feats = pd.DataFrame({'OPEN_TIME': data.OPEN_TIME.values})
    
    vol_feats['BV_GREATER_TBV'] = (bv  > tbv).astype(int)
    vol_feats['BV_EQUAL_TBV'  ] = (bv == tbv).astype(int)
    vol_feats['BV_LESSER_TBV' ] = (bv  < tbv).astype(int)
    vol_feats['QV_GREATER_TQV'] = (qv  > tqv).astype(int)
    vol_feats['QV_EQUAL_TQV'  ] = (qv == tqv).astype(int)
    vol_feats['QV_LESSER_TQV' ] = (qv  < tqv).astype(int)
    
    vol_feats['BV_QV_FRAC'    ] = bv / qv
    vol_feats['QV_BV_FRAC'    ] = qv / bv
    vol_feats['BV_QV_FRAC_INV'] = 1 - bv / qv
    vol_feats['QV_BV_FRAC_INV'] = 1 - qv / bv
    
    vol_feats['TBV_TQV_FRAC'    ] = tbv / tqv
    vol_feats['TQV_TBV_FRAC'    ] = tqv / tbv
    vol_feats['TBV_TQV_FRAC_INV'] = 1 - tbv / tqv
    vol_feats['TQV_TBV_FRAC_INV'] = 1 - tqv / tbv
    
    vol_feats['BV_TBV_FRAC'    ] = bv / tbv
    vol_feats['TBV_BV_FRAC'    ] = tbv / bv
    vol_feats['BV_TBV_FRAC_INV'] = 1 - bv / tbv
    vol_feats['TBV_BV_FRAC_INV'] = 1 - tbv / bv
    
    vol_feats['QV_TQV_FRAC'    ] = qv / tqv
    vol_feats['TQV_QV_FRAC'    ] = tqv / qv
    vol_feats['QV_TQV_FRAC_INV'] = 1 - qv / tqv
    vol_feats['TQV_QV_FRAC_INV'] = 1 - tqv / qv
    
    vol_feats['BV_TBV_DIFF'    ] = bv - tbv
    vol_feats['QV_TQV_DIFF'    ] = qv - tqv
    
    vol_feats['BV_TBV_DIFF_ABS'] = np.abs(bv - tbv)
    vol_feats['QV_TQV_DIFF_ABS'] = np.abs(qv - tqv)
    
    return vol_feats

def ohlc_vol_feats(data):
    o = data.OPEN.values.astype(float)
    h = data.HIGH.values.astype(float)
    l = data.LOW.values.astype(float)
    c = data.CLOSE.values.astype(float)
    bv = data.VOLUME.values.astype(float)
    qv = data.QUOTE_VOL.values.astype(float)
    tbv = data.TAKE_BASE_VOL.values.astype(float)
    tqv = data.TAKE_QUOTE_VOL.values.astype(float)
    
    ohlc_vol_feats = pd.DataFrame({'OPEN_TIME': data.OPEN_TIME.values})
    
    ohlc_vol_feats['HL_BASE_VOL'] = h - l / bv
    ohlc_vol_feats['OHLC_BASE_VOL'] = h - o + h - l + c - l / bv
    ohlc_vol_feats['OLHC_BASE_VOL'] = o - l + h - l + h - c / bv
    
    ohlc_vol_feats['HL_QUOTE_VOL'] = h - l / qv
    ohlc_vol_feats['OHLC_QUOTE_VOL'] = h - o + h - l + c - l / qv
    ohlc_vol_feats['OLHC_QUOTE_VOL'] = o - l + h - l + h - c / qv
    
    ohlc_vol_feats['HL_TAKE_BASE_VOL'] = h - l / tbv
    ohlc_vol_feats['OHLC_TAKE_BASE_VOL'] = h - o + h - l + c - l / tbv
    ohlc_vol_feats['OLHC_TAKE_BASE_VOL'] = o - l + h - l + h - c / tbv
    
    ohlc_vol_feats['HL_TAKE_QUOTE_VOL'] = h - l / tqv
    ohlc_vol_feats['OHLC_TAKE_QUOTE_VOL'] = h - o + h - l + c - l / tqv
    ohlc_vol_feats['OLHC_TAKE_QUOTE_VOL'] = o - l + h - l + h - c / tqv
    
    ohlc_vol_feats['HL_BASE_VOL_INV']   = 1 / ohlc_vol_feats['HL_BASE_VOL']
    ohlc_vol_feats['OHLC_BASE_VOL_INV'] = 1 / ohlc_vol_feats['OHLC_BASE_VOL']
    ohlc_vol_feats['OLHC_BASE_VOL_INV'] = 1 / ohlc_vol_feats['OLHC_BASE_VOL']
    
    ohlc_vol_feats['HL_QUOTE_VOL_INV']   = 1 / ohlc_vol_feats['HL_QUOTE_VOL']
    ohlc_vol_feats['OHLC_QUOTE_VOL_INV'] = 1 / ohlc_vol_feats['OHLC_QUOTE_VOL']
    ohlc_vol_feats['OLHC_QUOTE_VOL_INV'] = 1 / ohlc_vol_feats['OLHC_QUOTE_VOL']
    
    ohlc_vol_feats['HL_TAKE_BASE_VOL_INV']   = 1 / ohlc_vol_feats['HL_TAKE_BASE_VOL']
    ohlc_vol_feats['OHLC_TAKE_BASE_VOL_INV'] = 1 / ohlc_vol_feats['OHLC_TAKE_BASE_VOL']
    ohlc_vol_feats['OLHC_TAKE_BASE_VOL_INV'] = 1 / ohlc_vol_feats['OLHC_TAKE_BASE_VOL']
    
    ohlc_vol_feats['HL_TAKE_QUOTE_VOL_INV']   = 1 / ohlc_vol_feats['HL_TAKE_QUOTE_VOL']
    ohlc_vol_feats['OHLC_TAKE_QUOTE_VOL_INV'] = 1 / ohlc_vol_feats['OHLC_TAKE_QUOTE_VOL']
    ohlc_vol_feats['OLHC_TAKE_QUOTE_VOL_INV'] = 1 / ohlc_vol_feats['OLHC_TAKE_QUOTE_VOL']
    
    return ohlc_vol_feats

def num_trades_feats(data):
    o = data.OPEN.values.astype(float)
    h = data.HIGH.values.astype(float)
    l = data.LOW.values.astype(float)
    c = data.CLOSE.values.astype(float)
    bv = data.VOLUME.values.astype(float)
    qv = data.QUOTE_VOL.values.astype(float)
    tbv = data.TAKE_BASE_VOL.values.astype(float)
    tqv = data.TAKE_QUOTE_VOL.values.astype(float)
    nt = data.NUM_TRADES.values.astype(float)
    
    num_feats = pd.DataFrame({'OPEN_TIME': data.OPEN_TIME.values})
    
    num_feats['num_trades_inv']     = 1/nt
    
    # Vol feats
    num_feats['NUM_TRADES_PER_BV' ] = nt/bv
    num_feats['NUM_TRADES_PER_QV' ] = nt/qv
    num_feats['NUM_TRADES_PER_TBV'] = nt/tbv
    num_feats['NUM_TRADES_PER_TQV'] = nt/tqv
    
    num_feats['BV_PER_NUM_TRADES' ] = bv/nt
    num_feats['QV_PER_NUM_TRADES' ] = qv/nt
    num_feats['TBV_PER_NUM_TRADES'] = tbv/nt
    num_feats['TQV_PER_NUM_TRADES'] = tqv/nt
    
    # OHLC feats
    num_feats['NUM_TRADES_HL_SPREAD'    ] = h - l / nt
    num_feats['NUM_TRADES_HL_SPREAD_INV'] = nt / h - l
    num_feats['NUM_TRADES_HL_AVG'       ] = (h + l)/2 / nt
    num_feats['NUM_TRADES_OC_AVG'       ] = (o + c)/2 / nt
    
    return num_feats