import pandas as pd
import numpy as np
import requests

BASE_ENDPOINT = 'https://api.binance.com'
CANDLE = '/api/v1/klines'

def get_binance_data(endTime, symbol='ETHBTC'):
    response = requests.get(BASE_ENDPOINT+CANDLE+'?symbol='+symbol+'&interval=1m&endTime='+str(endTime))
    df = pd.DataFrame(
        data=np.array(response.json()), 
        columns=['OPEN_TIME', 'OPEN', 'HIGH', 'LOW', 'CLOSE', 'VOLUME', 'CLOSE_TIME', 'QUOTE_VOL', 'NUM_TRADES', 'TAKE_BASE_VOL', 'TAKE_QUOTE_VOL', 'EXTRA']
    )
    return df