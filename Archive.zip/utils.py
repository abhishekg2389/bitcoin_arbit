import numpy as np
import pandas as pd
import os

def add_result(modelName, data, prediction):
    data = data.copy()
    data[modelName+'_PREDICTION'] = [prediction]
    data[modelName+'_TRUE'] = [np.nan]
    
    if os.path.isfile('output/'+modelName+'.results'):
        res = pd.read_csv(modelName+'.results')
        res = res.append(data, ignore_index=True)
        res = res.drop_duplicates(subset=['OPEN_TIME', modelName+'_PREDICTION', modelName+'_TRUE'], keep='last')
    else:
        res = data
    
    assert(len(np.unique(res['OPEN_TIME'].values)) == res.shape[0])
    
    res.to_csv('output/'+modelName+'.results', index=False)